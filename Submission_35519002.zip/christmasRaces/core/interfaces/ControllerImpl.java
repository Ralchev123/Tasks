package christmasRaces.core;

import java.util.List;
import java.util.ArrayList;

import christmasRaces.core.interfaces.Controller;
import christmasRaces.entities.cars.Car;
import christmasRaces.entities.drivers.Driver;
import christmasRaces.entities.races.Race;
import christmasRaces.repositories.interfaces.Repository;
import christmasRaces.entities.drivers.DriverImpl;
import christmasRaces.entities.cars.MuscleCar;
import christmasRaces.entities.cars.SportsCar;
import christmasRaces.entities.races.RaceImpl;

public class ControllerImpl implements Controller {
    private Repository<Driver> driverRepository;
    private Repository<Car> carRepository;
    private Repository<Race> raceRepository;

    public ControllerImpl(Repository<Driver> driverRepository, Repository<Car> carRepository, Repository<Race> raceRepository) {
        this.driverRepository = driverRepository;
        this.carRepository = carRepository;
        this.raceRepository = raceRepository;
    }

    @Override
    public String createDriver(String driverName) {
        if (driverRepository.getByName(driverName) != null) {
            throw new IllegalArgumentException("Driver " + driverName + " is already created.");
        }

        Driver driver = new DriverImpl(driverName);
        driverRepository.add(driver);

        return "Driver " + driverName + " is created.";
    }

    @Override
    public String createCar(String type, String model, int horsePower) {
        Car car = null;

        if (type.equals("Muscle")) {
            car = new MuscleCar(model, horsePower);
        } else if (type.equals("Sports")) {
            car = new SportsCar(model, horsePower);
        }

        if (carRepository.getByName(model) != null) {
            throw new IllegalArgumentException("Car " + model + " is already created.");
        }

        carRepository.add(car);

        return car.getClass().getSimpleName() + " " + model + " is created.";
    }

    @Override
    public String addCarToDriver(String driverName, String carModel) {
        Driver driver = driverRepository.getByName(driverName);
        if (driver == null) {
            throw new IllegalArgumentException("Driver " + driverName + " could not be found.");
        }

        Car car = carRepository.getByName(carModel);
        if (car == null) {
            throw new IllegalArgumentException("Car " + carModel + " could not be found.");
        }

        driver.addCar(car);
        return "Driver " + driverName + " received car " + carModel + ".";
    }

    @Override
    public String addDriverToRace(String raceName, String driverName) {
        Race race = raceRepository.getByName(raceName);
        if (race == null) {
            throw new IllegalArgumentException("Race " + raceName + " could not be found.");
        }

        Driver driver = driverRepository.getByName(driverName);
        if (driver == null) {
            throw new IllegalArgumentException("Driver " + driverName + " could not be found.");
        }

        if (!driver.getCanParticipate()) {
            throw new IllegalArgumentException("Driver " + driverName + " could not participate in race.");
        }

        race.addDriver(driver);
        return "Driver " + driverName + " added in " + raceName + " race.";
    }

    @Override
    public String startRace(String raceName) {
        Race race = raceRepository.getByName(raceName);
        if (race == null) {
            throw new IllegalArgumentException("Race " + raceName + " could not be found.");
        }

        if (race.getDrivers().size() < 3) {
            throw new IllegalArgumentException("Race " + raceName + " cannot start with less than 3 participants.");
        }

        List<Driver> drivers = new ArrayList<>(race.getDrivers());
        drivers.sort((driver1, driver2) ->
                Double.compare(driver2.getCar().calculateRacePoints(race.getLaps()),
                        driver1.getCar().calculateRacePoints(race.getLaps())));

        raceRepository.remove(race);
        return "Driver " + drivers.get(0).getName() + " wins " + raceName + " race."
                + "\nDriver " + drivers.get(1).getName() + " is second in " + raceName + " race."
                + "\nDriver " + drivers.get(2).getName() + " is third in " + raceName + " race.";
    }

    @Override
    public String createRace(String name, int laps) {
        Race race = raceRepository.getByName(name);
        if (race != null) {
            throw new IllegalArgumentException("Race " + name + " is already created.");
        }

        race = new RaceImpl(name, laps);
        raceRepository.add(race);

        return "Race " + name + " is created.";
    }
}
