package christmasRaces.entities.cars;

public abstract class BaseCar implements Car {
       private String model;
    private int horsePower;
    private double cubicCentimeters;

    public BaseCar(String model, int horsePower, double cubicCentimeters) {
        setModel(model);
        setHorsePower(horsePower);
        this.cubicCentimeters = cubicCentimeters;
    }

    protected void setModel(String model) {
        if (model == null || model.trim().isEmpty() || model.length() < 4) {
            throw new IllegalArgumentException("Model " + model + " cannot be less than 4 symbols.");
        }
        this.model = model;
    }

    protected void setHorsePower(int horsePower) {
        if (!isValidHorsePower(horsePower)) {
            throw new IllegalArgumentException("Invalid horse power: " + horsePower + ".");
        }
        this.horsePower = horsePower;
    }

    protected abstract boolean isValidHorsePower(int horsePower);

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public int getHorsePower() {
        return horsePower;
    }

    @Override
    public double getCubicCentimeters() {
        return cubicCentimeters;
    }

    @Override
    public double calculateRacePoints(int laps) {
        return cubicCentimeters / horsePower * laps;
    }
}